import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='labibahtrd',
    application_name='task1',
    app_uid='dgdpsTLkLVHR1CVf8L',
    org_uid='d8497c2d-d294-44d1-87ff-ac6565072ed1',
    deployment_uid='f4af0ad2-93ec-4ba9-b3e6-6b64db965c74',
    service_name='CirclTask',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.4',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'CirclTask-dev-uploadCustomer', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('CirclTask/handler.uploadCustomer')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
